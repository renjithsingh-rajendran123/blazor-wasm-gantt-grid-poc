﻿function ButtonClick(message)
{
    alert(message);
}
